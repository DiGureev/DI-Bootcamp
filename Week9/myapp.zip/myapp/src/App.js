// import Hello from "./Hello";
import User from "./components/User";
import "./App.css";
import 'tachyons';

import users from "./users.json";

// const users = [
//   { id: 1, name: "Alla", email: "al@gmail.com", username: "allala" },
//   { id: 2, name: "Dan", email: "dn@gmail.com", username: "dandan" },
//   { id: 3, name: "John", email: "jn@gmail.com", username: "johnjohn" },
//   { id: 4, name: "Marina", email: "mr@gmail.com", username: "mrmr" },
//   { id: 5, name: "aaa", email: "aa@gmail.com", username: "aaa" },
// ];

function App() {
  return (
    <div className="App">
      <header className="App-header-">
        {users.map((item) => {
          return <User info={item} key={item.id} />;
        })}
      </header>
    </div>
  );
}

export default App;

/* <Hello name="John" email="john@gmail.com"/>
        <Hello name="Marry" email="marry@gmail.com"/> */

/*
1. create a components folder in src 
2. cretae a User component
3. pass name, username, email to the User component
4. Show 2 diffrents Users on your page
*/
