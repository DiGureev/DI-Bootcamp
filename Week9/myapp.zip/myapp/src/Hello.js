const Hello = (props) => {
  console.log("props=>", props);
  const { name, email } = props;

  return (
    <>
      <h1>Hello {name}</h1>
      <p>{email}</p>
    </>
  );
};
export default Hello;
