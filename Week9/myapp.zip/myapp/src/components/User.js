import "./User.css";
import React, { Component } from "react";

// const User = (props) => {
//   const { name, email, username, address, id } = props.info;

//   return (
//     <div className="tc bg-light-green br3 pd3 ma2 dib bw2 grow shadow-5">
//       <img src={`https://robohash.org/${id}?size=150x150`}/>
//       <h4>{name}</h4>
//       <p>{username}</p>
//     </div>
//   );
// };
// export default User;

class User extends Component {
  render() {
    const { name, email, username, address, id } = this.props.info;
    return (
      <div className="tc bg-light-green br3 pa3 ma2 dib bw2 grow shadow-5">
        <img src={`https://robohash.org/${id}?size=150x150`} />
        <h4>{name}</h4>
        <p>{username}</p>
      </div>
    );
  }
}
export default User;
